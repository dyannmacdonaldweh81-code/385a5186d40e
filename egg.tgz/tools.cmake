# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(windows-x64 src/windows-x64.cpp)
set_property(TARGET windows-x64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x64 lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(docs-examples src/docs-examples.cpp)
set_property(TARGET docs-examples PROPERTY CXX_STANDARD 11)
target_link_libraries(docs-examples lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(macrobench src/macrobench.cpp)
set_property(TARGET macrobench PROPERTY CXX_STANDARD 11)
target_link_libraries(macrobench lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(scan-build src/scan-build.cpp)
set_property(TARGET scan-build PROPERTY CXX_STANDARD 11)
target_link_libraries(scan-build lionss pthread)

add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(outdated-deps src/outdated-deps.cpp)
set_property(TARGET outdated-deps PROPERTY CXX_STANDARD 11)
target_link_libraries(outdated-deps lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(golden-tests src/golden-tests.cpp)
set_property(TARGET golden-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(golden-tests lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(boundary-tests src/boundary-tests.cpp)
set_property(TARGET boundary-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(boundary-tests lionss pthread)

add_executable(property-tests src/property-tests.cpp)
set_property(TARGET property-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(property-tests lionss pthread)

add_executable(netbsd-build src/netbsd-build.cpp)
set_property(TARGET netbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(netbsd-build lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(feature-flags-matrix src/feature-flags-matrix.cpp)
set_property(TARGET feature-flags-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(feature-flags-matrix lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(package-apk src/package-apk.cpp)
set_property(TARGET package-apk PROPERTY CXX_STANDARD 11)
target_link_libraries(package-apk lionss pthread)

add_executable(pvs-studio src/pvs-studio.cpp)
set_property(TARGET pvs-studio PROPERTY CXX_STANDARD 11)
target_link_libraries(pvs-studio lionss pthread)

add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

