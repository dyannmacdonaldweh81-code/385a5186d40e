// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("valgrind helgrind"); }
int main(){
  announce();
  return lionss_run_workload("valgrind-helgrind");
}
