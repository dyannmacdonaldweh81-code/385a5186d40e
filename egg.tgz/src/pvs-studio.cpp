// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pvs studio\n", stdout);
  return lionss_run_workload("pvs-studio");
}
