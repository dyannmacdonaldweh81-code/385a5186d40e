// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("asan ubsan"); }
int main(){
  announce();
  return lionss_run_workload("asan-ubsan");
}
