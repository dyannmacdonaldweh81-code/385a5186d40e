// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("section sizes\n", stdout);
  return lionss_run_workload("section-sizes");
}
